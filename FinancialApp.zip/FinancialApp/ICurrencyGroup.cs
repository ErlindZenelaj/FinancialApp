﻿internal interface ICurrencyGroup
{
}