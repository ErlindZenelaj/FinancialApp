﻿internal class CurrencyGroupRepo
{
}